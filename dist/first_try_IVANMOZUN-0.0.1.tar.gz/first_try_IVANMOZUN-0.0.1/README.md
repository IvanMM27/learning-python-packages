# learning-python-packages
This is first try to learn how to use python packages and GitHub.

Tutorial video: https://www.youtube.com/watch?v=ueuLe4PipiI

